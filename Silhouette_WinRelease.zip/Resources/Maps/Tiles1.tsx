<?xml version="1.0" encoding="UTF-8"?>
<tileset version="1.10" tiledversion="1.11.0" name="Tiles1" tilewidth="26" tileheight="22" tilecount="400" columns="20">
 <image source="../Textures/Tiles1.png" width="520" height="440"/>
</tileset>
