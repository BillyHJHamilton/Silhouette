<?xml version="1.0" encoding="UTF-8"?>
<tileset version="1.10" tiledversion="1.11.0" name="Temp" tilewidth="44" tileheight="44" tilecount="12" columns="6" objectalignment="topleft">
 <image source="../Textures/BalletSheet.png" width="264" height="88"/>
 <tile id="0" type="Player"/>
 <tile id="1" type="StrobeLight"/>
</tileset>
