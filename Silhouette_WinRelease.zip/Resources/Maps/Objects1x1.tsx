<?xml version="1.0" encoding="UTF-8"?>
<tileset version="1.10" tiledversion="1.11.0" name="Objects1x1" tilewidth="26" tileheight="22" tilecount="1" columns="1" objectalignment="topleft">
 <image source="../Textures/Objects1x1.png" width="26" height="22"/>
 <tile id="0" type="StrobeLight"/>
</tileset>
